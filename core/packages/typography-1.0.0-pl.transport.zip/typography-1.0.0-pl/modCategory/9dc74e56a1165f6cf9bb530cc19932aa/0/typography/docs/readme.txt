Typography
==========
Beautiful typesetting without the work.

Proper typesetting can help increase reader retention and understanding, because text flows better and is easier to folllow. There is unlimited content on the web. Typography aims to make yours more impactful.

For full details, see http://rthrash.github.io/typography/


Installation
------------
Install via Package Managmenet.


Usage
-----
Use as an output filter. For example, to add to your main `[[*content]]`:

```
[[*content:typography]]
```

