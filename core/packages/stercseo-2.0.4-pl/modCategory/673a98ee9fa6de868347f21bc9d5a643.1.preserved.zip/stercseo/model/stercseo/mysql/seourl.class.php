<?php
/**
 * @package seopro
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/seourl.class.php');
class seoUrl_mysql extends seoUrl {}
?>